import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Route, Link, NavLink, Switch } from 'react-router-dom';
import About from './pages/about.jsx';
import Home from './pages/home.jsx'






const App = () => (

  <Router>
    <div>
      <nav className="navbar navbar-default">
        <div className="container">
          <ul className="nav navbar-nav">

            <li className="selected"><NavLink exact to="/">Home</NavLink></li>
            <li><NavLink exact to="/pages/about">About</NavLink></li>
          </ul >
        </div>
      </nav>


      <Switch>
        <Route exact path="/" component={Home} />
        <Route exact path="/pages/about" component={About} />
      </Switch>
    </div >
  </Router >

)

export default App;
