import React, { Component } from 'react';
import { Row, Col, Table, Pagination, FormGroup, FormControl, InputGroup, OverlayTrigger, Tooltip, SplitButton, MenuItem, Modal, ControlLabel, Form, Button, ButtonToolbar, DropdownButton, span } from 'react-bootstrap';



class About extends React.Component {
  constructor() {
    super();


    this.state = {
      designation: "Developer",
      name: "Kaushal"

    }

  }

  render() {
    // setTimeout(() => {

    //   this.setState({ name: "Nitin" })

    // }, 2000)


    return (
      <div className="container">

        <div className="jumbotron custom_jumbotron">
          {this.state.name}
          {this.state.designation}
          <h1>Navbar example</h1>
          <p>This example is a quick exercise to illustrate how the default, static navbar and fixed to top navbar work. It includes the responsive CSS and HTML, so it also adapts to your viewport and device.</p>
          <p>

            <a class="btn btn-lg btn-primary" href="../../components/#navbar" role="button">View navbar docs »</a>
          </p>
        </div>




      </div>


    );

  }

}

export default About;