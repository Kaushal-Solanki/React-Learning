import React, { Component } from 'react';


class Home extends React.Component {

  render() {

    return (

      <div className="container">
        <h1>This is the Home Page</h1>
      </div>

    );

  }

}

export default Home;